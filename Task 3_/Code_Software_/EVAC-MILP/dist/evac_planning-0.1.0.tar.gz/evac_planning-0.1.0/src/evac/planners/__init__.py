"""Planning implementations."""
